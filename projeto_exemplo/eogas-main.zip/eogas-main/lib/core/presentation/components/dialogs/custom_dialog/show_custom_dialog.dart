import 'package:eogas/core/presentation/components/dialogs/custom_dialog/custom_dialog_information.dart';
import 'package:flutter/material.dart';

showCustomDialog({
  required String title,
  required String description,
  required BuildContext context,
  String? urlToImage,
  String? errorToCopy,
  CustomDialogTypes? customDialogType,
  String? leftButtonText,
  String? rigthButtonText,
  VoidCallback? onLeftButtonPressed,
  Function? onRightButtonPressed,
  Color? leftButtonColor,
  Color? rightButtonColor,
}) async {
  assert((leftButtonText != null && onLeftButtonPressed != null) ||
      (leftButtonText == null && onLeftButtonPressed == null));
  // print(errorToCopy);
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) => CustomDialogInformation(
      title: title,
      description: description,
      urlToImage: urlToImage,
      customDialogType: customDialogType ?? CustomDialogTypes.Success,
      leftButtonText: leftButtonText,
      rigthButtonText: rigthButtonText,
      onLeftButtonPressed: onLeftButtonPressed,
      onRigthButtonPressed: onRightButtonPressed,
      errorToCopy: errorToCopy,
      leftButtonColor: leftButtonColor,
      rightButtonColor: rightButtonColor,
    ),
  );
}
