import 'package:eogas/core/presentation/components/buttons/default_text_button.dart';
import 'package:eogas/core/presentation/components/dialogs/custom_dialog/custom_dialog_information.dart';
import 'package:flutter/material.dart';

class CustomDialogButtonsWidget extends StatelessWidget {
  final VoidCallback? onLeftButtonPressed;
  final Function? onRigthButtonPressed;
  final CustomDialogTypes customDialogType;
  final Color? rigthButtonColor;
  final Color? leftButtonColor;
  final String? leftButtonText;
  final String? rigthButtonText;

  const CustomDialogButtonsWidget({
    this.onLeftButtonPressed,
    required this.customDialogType,
    this.leftButtonColor,
    this.rigthButtonColor,
    this.leftButtonText,
    this.onRigthButtonPressed,
    this.rigthButtonText,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Visibility(
          visible: this.onLeftButtonPressed != null,
          child: DefaultTextButton(
            textColor: this.leftButtonColor ?? _leftButtonColor(),
            text: leftButtonText ?? '',
            onPressed:
                onLeftButtonPressed != null ? onLeftButtonPressed! : () {},
            // buttonColor: this.leftButtonColor ?? _leftButtonColor(),
          ),
        ),
        Visibility(
          visible: this.onLeftButtonPressed != null,
          child: SizedBox(
            width: 10,
          ),
        ),
        DefaultTextButton(
          textColor: this.leftButtonColor ?? _rightButtonColor(),
          text: rigthButtonText ?? 'OK',
          onPressed: () {
            if (onRigthButtonPressed == null)
              Navigator.of(context).pop();
            else {
              onRigthButtonPressed!();
              Navigator.of(context).pop();
            }
          },
          // buttonColor: rigthButtonColor ?? _rightButtonColor(),
        ),
      ],
    );
  }

  _rightButtonColor() {
    if (customDialogType == CustomDialogTypes.Success)
      return Colors.green[400];
    else if (customDialogType == CustomDialogTypes.Fail)
      return Colors.red[900];
    else if (customDialogType == CustomDialogTypes.Warning)
      return Colors.yellow[400];
    else if (customDialogType == CustomDialogTypes.Question)
      return Colors.teal[500];
  }

  _leftButtonColor() {
    if (customDialogType == CustomDialogTypes.Success)
      return Colors.green[300];
    else if (customDialogType == CustomDialogTypes.Fail)
      return Colors.red[400];
    else if (customDialogType == CustomDialogTypes.Question)
      return Colors.teal[300];
  }
}
