import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const kTitleEdgeInsets = EdgeInsets.only(top: 15, bottom: 30);
const kTitleFontSize = 32.0;
const kTitleFontWeight = FontWeight.bold;

const kSubTitleEdgeInsets = EdgeInsets.only(left: 8.0);
const kSubTitleFontSize = 14.0;
const kSubTitleFontWeight = FontWeight.normal;

class AccessTextWidget extends StatelessWidget {
  final String text;
  final EdgeInsets edgeInsets;
  final double fontSize;
  final FontWeight fontWeight;

  const AccessTextWidget({
    required this.text,
    this.edgeInsets = const EdgeInsets.all(0),
    this.fontSize = kSubTitleFontSize,
    this.fontWeight = kSubTitleFontWeight,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: edgeInsets,
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: fontSize,
          fontWeight: fontWeight,
        ),
      ),
    );
  }
}
