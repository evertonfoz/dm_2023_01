import 'package:eogas/core/constants.dart';
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RichTextTextOrientation extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore passwordForgotStore;

  const RichTextTextOrientation({required this.passwordForgotStore});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0),
      child: RichText(
        textAlign: TextAlign.start,
        text: TextSpan(
          style: GoogleFonts.poppins(
            fontSize: 14,
            color: kThirdColor,
          ),
          children: <TextSpan>[
            TextSpan(text: 'Insira o código que foi enviado para o '),
            TextSpan(
              text: _extractTextToEmailOrCellPhone(),
              style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: " nos campos abaixo "),
          ],
        ),
      ),
    );
  }

  _extractTextToEmailOrCellPhone() {
    String valueToReturn;
    if (passwordForgotStore.emailIsSelected) {
      int indexOfAt = passwordForgotStore.email.indexOf('@');
      valueToReturn =
          ' email ${passwordForgotStore.email.substring(0, 2)}*****${passwordForgotStore.email.substring(indexOfAt)}';
    } else {
      valueToReturn =
          ' número ${passwordForgotStore.cellPhone.substring(0, 4)}*****${passwordForgotStore.cellPhone.substring(13)}';
    }
    return valueToReturn;
  }
}
