import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/appbar/appbar.dart';
import 'package:eogas/core/presentation/components/dialogs/custom_dialog/custom_dialog_information.dart';
import 'package:eogas/core/presentation/components/dialogs/custom_dialog/show_custom_dialog.dart';
import 'package:eogas/core/presentation/components/in_processing/in_processing.dart';
import 'package:eogas/core/presentation/components/scaffold/body_padding.dart';
import 'package:eogas/core/presentation/mobx_store/in_processing_store.dart';
import 'package:eogas/features/access/presentation/components/access_button.dart';
import 'package:eogas/features/access/presentation/components/access_text.dart';
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:eogas/features/access/presentation/pages/code_verify/components/code_not_received_text.dart';
import 'package:eogas/features/access/presentation/pages/code_verify/components/pin_code_to_recover_password.dart';
import 'package:eogas/features/access/presentation/pages/code_verify/components/richtext_text_orientation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get_it/get_it.dart';
import 'package:google_fonts/google_fonts.dart';

class CodeVerifyToRecoverPasswordPage extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore passwordForgotStore;

  const CodeVerifyToRecoverPasswordPage({required this.passwordForgotStore});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: Observer(builder: (_) {
        return BodyPaddingWidget(
          left: 16,
          child: Stack(
            children: [
              _pageOrInProcessing(),
              InProcessingWidget(),
            ],
          ),
        );
      }),
    );
  }

  _pageOrInProcessing() {
    if (!GetIt.I.get<InProcessingStore>().isInProcessing) {
      return _buildPage();
    }

    return AbsorbPointer(
      child: Opacity(
        opacity: 0.3,
        child: _buildPage(),
      ),
    );
  }

  _buildPage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AccessTextWidget(
          text: 'Verificação',
          edgeInsets: kTitleEdgeInsets,
          fontSize: kTitleFontSize,
          fontWeight: kTitleFontWeight,
        ),
        RichTextTextOrientation(
          passwordForgotStore: passwordForgotStore,
        ),
        SizedBox(height: 40),
        Observer(builder: (_) {
          return PinCodeToRecoverPassword(
            validator: passwordForgotStore.registerCodeIsComplete,
            obscureCode: passwordForgotStore.obscureCode,
          );
        }),
        // SizedBox(height: 10),
        Observer(builder: (_) {
          return InkWell(
            onTap: () => passwordForgotStore.registerTurnObscureCode(),
            child: Center(
              child: Icon(
                passwordForgotStore.obscureCode
                    ? FontAwesomeIcons.eye
                    : FontAwesomeIcons.eyeSlash,
              ),
            ),
          );
        }),
        Observer(
          builder: (_) => AccessButtonWidget(
            text: 'Confirmar',
            onPressed: passwordForgotStore.codeIsComplete
                ? () => Navigator.pushNamed(
                    passwordForgotStore.buildContext!, kNewPasswordRoute)
                : null,
          ),
        ),
        SizedBox(height: 30),
        CodeNotReceivedText(
          passwordForgotStore: passwordForgotStore,
        ),
      ],
    );
  }

  _buildAppBar(BuildContext context) {
    return PreferredSize(
      preferredSize: Size.fromHeight(kToolbarHeight),
      child: AppBarEOG(
        actions: [
          InkWell(
            onTap: () => showCustomDialog(
                // context: authenticationBaseForm.context,
                title: 'Cancelar redefinição de senha?',
                description:
                    'Você será redirecionado(a) para a tela de início. OK?',
                urlToImage: 'assets/images/brand/brand_100x70_transparent.png',
                customDialogType: CustomDialogTypes.Fail,
                context: context,
                leftButtonText: 'OK. Entendi!',
                // leftButtonColor: Colors.red.shade900,
                rigthButtonText: 'Ooops. Quero ficar!',
                // rightButtonColor: Colors.red.shade500,
                onLeftButtonPressed: () =>
                    Navigator.pushReplacementNamed(context, kWelcomeRoute)
                // onRightButtonPressed: () {},
                ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 12.0),
                child: Text(
                  'Cancelar',
                  style: GoogleFonts.poppins(
                    color: kSecondaryColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
