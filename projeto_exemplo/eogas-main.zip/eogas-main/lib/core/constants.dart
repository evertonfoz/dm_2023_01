import 'package:flutter/material.dart';

const kPrimaryColor = Colors.white;
const kSecondaryColor = Colors.orange;
const kThirdColor = Colors.red;

const kAnimationDuration = Duration(milliseconds: 200);
const kPageTranstionsPreference = 'pageTransitions';

/// Routes
const String kWelcomeRoute = '/welcome';
const String kAccessPageRoute = '/access';
const String kHomePageRoute = '/home';
const String kLoginPageRoute = '/login';
const String kRegisterPageRoute = '/register';
const String kFacebookAccessRoute = '/facebook';
const String kGoogleAccessRoute = '/google';
const String kPasswordForgot = '/passwordForgot';
const String kCodeVerifyToRecoverPasswordRoute = '/codeVerify';
const String kNewPasswordRoute = '/newPassword';

/// Colors
const kTextColor = Colors.black;
const kLabelTextColor = Colors.yellow;
const kErrorTextColor = Colors.yellow;
const kTextFieldFillColor = Colors.grey;

/// Brand
const kBrandImage = 'assets/images/brand/launch.png';
