package com.example.eogas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
