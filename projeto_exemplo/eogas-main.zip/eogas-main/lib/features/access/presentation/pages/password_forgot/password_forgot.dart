import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/snackbar/snackbar.dart';
import 'package:eogas/core/presentation/components/appbar/appbar.dart';
import 'package:eogas/core/presentation/components/in_processing/in_processing.dart';
import 'package:eogas/core/presentation/components/scaffold/body_padding.dart';
import 'package:eogas/core/presentation/mobx_store/in_processing_store.dart';
import 'package:eogas/features/access/presentation/components/access_button.dart';
import 'package:eogas/features/access/presentation/components/access_text.dart';
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:eogas/features/access/presentation/pages/password_forgot/components/cellphone_textfield_to_recover_password.dart';
import 'package:eogas/features/access/presentation/pages/password_forgot/components/email_textfield_to_recover_password.dart';
import 'package:eogas/features/access/presentation/pages/password_forgot/components/means_to_recover_password.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:get_it/get_it.dart';

class PasswordForgotPage extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore _passwordForgotStore =
      PasswordForgotAndCodeVerifyStore();

  final TextEditingController _emailTextController = TextEditingController();
  final TextEditingController _cellPhoneTextController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    _passwordForgotStore.registerBuildContext(value: context);

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight),
        child: AppBarEOG(),
      ),
      body: Observer(
        builder: (_) {
          return BodyPaddingWidget(
            left: 16,
            child: Stack(
              children: [
                _pageOrInProcessing(),
                InProcessingWidget(),
              ],
            ),
          );
        },
      ),
    );
  }

  _pageOrInProcessing() {
    if (!GetIt.I.get<InProcessingStore>().isInProcessing) {
      return _buildPage();
    }

    return AbsorbPointer(
      child: Opacity(
        opacity: 0.3,
        child: _buildPage(),
      ),
    );
  }

  _buildPage() {
    return SingleChildScrollView(
      child: Observer(builder: (_) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AccessTextWidget(
              text: 'Esqueceu sua senha?',
              edgeInsets: kTitleEdgeInsets,
              fontSize: kTitleFontSize,
              fontWeight: kTitleFontWeight,
            ),
            AccessTextWidget(
              text:
                  'Preencha o campo abaixo e enviaremos um código de verificação de cadastro.',
              edgeInsets: kSubTitleEdgeInsets,
            ),
            SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: MeansToRecoverPasswordWidget(
                passwordForgotStore: _passwordForgotStore,
              ),
            ),
            SizedBox(height: 30),
            EmailTextFieldToRecoverPassword(
              passwordForgotStore: _passwordForgotStore,
              emailTextController: _emailTextController,
            ),
            CellPhoneTextFieldToRecoverPassword(
              passwordForgotStore: _passwordForgotStore,
              cellPhoneTextController: _cellPhoneTextController,
            ),
            SizedBox(height: 30),
            AccessButtonWidget(
              text: 'Resetar senha',
              onPressed: _passwordForgotStore.formIsValid
                  ? _onPressAccessButton
                  : null,
            ),
          ],
        );
      }),
    );
  }

  _onPressAccessButton() {
    FocusScope.of(_passwordForgotStore.buildContext!).unfocus();

    _passwordForgotStore.registerEmail(_emailTextController.text);
    _passwordForgotStore.registerCellPhone(_cellPhoneTextController.text);

    GetIt.I.get<InProcessingStore>().registerIsInProcessing(true);

    showBottomSnackBar(
      context: _passwordForgotStore.buildContext!,
      durationSeconds: 3,
      // title: 'Informação',
      content: 'Código enviado para o seu ' +
          (_passwordForgotStore.emailIsSelected ? ' email ' : 'celular '),
    );

    Future.delayed(const Duration(seconds: 3), () {
      GetIt.I.get<InProcessingStore>().registerIsInProcessing(false);

      Navigator.pushNamed(
        _passwordForgotStore.buildContext!,
        kCodeVerifyToRecoverPasswordRoute,
        arguments: _passwordForgotStore,
      );
    });
  }
}
