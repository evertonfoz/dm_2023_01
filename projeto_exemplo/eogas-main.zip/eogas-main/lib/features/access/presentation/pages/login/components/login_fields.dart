import 'package:eogas/core/presentation/components/textformfield/textformfield.dart';
import 'package:eogas/features/access/presentation/pages/constants.dart';
import 'package:eogas/features/access/presentation/pages/login/mobx_stores/login_store.dart';
import 'package:flutter/material.dart';
import 'package:eogas/core/presentation/business/text_validators.dart'
    as validators;
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ignore: must_be_immutable
class LoginFieldsWidget extends StatelessWidget {
  final LoginStore loginStore;
  final VoidCallback? onPressAditionalSufixIcon;

  LoginFieldsWidget({
    required this.loginStore,
    this.onPressAditionalSufixIcon,
  });

  String? _email = '';
  String? _password = '';

  @override
  Widget build(BuildContext context) {
    return Form(
      key: loginStore.formKey,
      autovalidateMode: loginStore.autoValidateModeForm,
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'E-Mail',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 10),
            TextFormFieldEOG(
              textInputType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              errorMessages: [
                kEmailNullError,
                kEmailInvalidError,
              ],
              validationFunctions: [
                (_email) => validators.isNotEmptyValidator(_email ?? ''),
                (_email) => validators.isAValidEmailValidator(_email ?? ''),
              ],
              onSaved: (newValue) => _email = newValue,
              registerInStoreForm: loginStore.registerEmailStatus,
            ),
            Text(
              'Senha',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 10),
            Observer(
              builder: (_) => TextFormFieldEOG(
                errorMaxLines: 2,
                obscureText: loginStore.obscurePasswordText,
                onPressAditionalSufixIcon: onPressAditionalSufixIcon,
                aditionalSufixIcons: [
                  FontAwesomeIcons.eye,
                  FontAwesomeIcons.eyeSlash,
                ],
                errorMessages: [
                  kPasswordNullError,
                  kPasswordInvalidError,
                ],
                validationFunctions: [
                  (_password) =>
                      validators.isNotEmptyValidator(_password ?? ''),
                  (_password) =>
                      validators.isAValidPasswordValidator(_password ?? ''),
                ],
                onSaved: (newValue) => _password = newValue,
                registerInStoreForm: loginStore.registerPasswordStatus,
              ),
            ),
            SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
