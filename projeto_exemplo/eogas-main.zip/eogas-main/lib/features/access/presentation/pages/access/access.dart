import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/brand/image_brand.dart';
import 'package:eogas/core/presentation/components/brand/title_e_o_gas.dart';
import 'package:eogas/core/presentation/components/buttons/default_elevated_button.dart';
import 'package:flutter/material.dart';

//imageURL: "assets/images/brand/launch.png",
class AccessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          // mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(flex: 1, child: EOGasTitle()),
            // SizedBox(height: 30),
            Expanded(flex: 4, child: BrandImage()),
            Expanded(
              flex: 1,
              child: _accessButtons(context),
            ),
          ],
        ),
      ),
    );
  }

  _accessButtons(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            child: DefaultElevatedButton(
              text: 'Acessar',
              textColor: Colors.white,
              buttonColor: kSecondaryColor,
              onPressed: () => Navigator.pushNamed(context, kLoginPageRoute),
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: DefaultElevatedButton(
              text: 'Cadastro',
              textColor: kSecondaryColor,
              buttonColor: Colors.white,
              borderColor: kSecondaryColor,
              borderWidth: 1,
              onPressed: () => Navigator.pushNamed(context, kRegisterPageRoute),
            ),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
