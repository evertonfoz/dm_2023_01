import 'package:eogas/core/constants.dart';
import 'package:eogas/features/access/presentation/pages/login/mobx_stores/login_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

import 'components/appbar.dart';
import 'components/login_access_button.dart';
import 'components/login_fields.dart';
import 'components/login_text.dart';
import 'components/social_network_area.dart';

class LoginPage extends StatelessWidget {
  final LoginStore _loginStore = LoginStore();

  @override
  Widget build(BuildContext context) {
    _loginStore.registerBuildContext(value: context);

    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: AppBarAccessWidget()),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              LoginTextWidget(),
              LoginFieldsWidget(
                loginStore: _loginStore,
                // formKey: _formKey,
                // autoValidateModeForm: _autoValidateModeForm,
                // obscurePasswordText: _obscurePasswordText,
                onPressAditionalSufixIcon: _onPressAditionalSufixIcon,
                // onValidateTextFields: () {}, //_onValidateTextFields(),
              ),
              Observer(
                builder: (_) => LoginAccessButtonWidget(
                  onPressed:
                      _loginStore.formIsValid ? _onPressAccessButton : null,
                ),
              ),
              SocialNetworkAreaWidget(),
            ],
          ),
        ),
      ),
    );
  }

  _onPressAccessButton() {
    FocusScope.of(_loginStore.buildContext!).unfocus();
    _loginStore.registerAutoValidateModeForm(value: AutovalidateMode.disabled);
    if (_loginStore.formKey.currentState!.validate()) {
      Navigator.pushNamed(_loginStore.buildContext!, kHomePageRoute);
    } else {
      _loginStore.registerAutoValidateModeForm(
          value: AutovalidateMode.onUserInteraction);
    }
  }

  _onPressAditionalSufixIcon() {
    _loginStore.registerObscurePasswordText(
        value: !_loginStore.obscurePasswordText);
  }
}
