import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/buttons/default_elevated_button.dart';
import 'package:flutter/material.dart';

class LoginAccessButtonWidget extends StatelessWidget {
  final VoidCallback? onPressed;

  const LoginAccessButtonWidget({
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0),
      child: Column(
        children: [
          SizedBox(height: 20),
          ConstrainedBox(
            constraints:
                BoxConstraints.tightFor(width: double.infinity, height: 50),
            child: DefaultElevatedButton(
              buttonColor: kSecondaryColor,
              textColor: kPrimaryColor,
              text: 'Acessar',
              onPressed: onPressed,
            ),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
