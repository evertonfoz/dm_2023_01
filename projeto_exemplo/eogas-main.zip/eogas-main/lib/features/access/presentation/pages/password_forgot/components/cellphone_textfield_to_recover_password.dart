import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:eogas/features/access/presentation/pages/constants.dart';
import 'package:eogas/features/access/presentation/pages/password_forgot/components/textfield_to_means_to_recover_password.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:eogas/core/presentation/business/text_validators.dart'
    as validators;

class CellPhoneTextFieldToRecoverPassword extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore passwordForgotStore;
  final TextEditingController cellPhoneTextController;

  CellPhoneTextFieldToRecoverPassword({
    required this.passwordForgotStore,
    required this.cellPhoneTextController,
  });

  final MaskTextInputFormatter phoneMaskFormatter = new MaskTextInputFormatter(
    mask: '(##) #####-####',
    filter: {
      "#": RegExp(r'[0-9]'),
    },
  );

  @override
  Widget build(BuildContext context) {
    return Observer(builder: (_) {
      return Visibility(
        visible: passwordForgotStore.cellPhoneIsSelected,
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Form(
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: TextFieldToMeansToRecoverPasswordWidget(
              prefixText: '+55 ',
              textInputFormatter: phoneMaskFormatter,
              textInputType: TextInputType.phone,
              text: 'Insira o número do seu celular',
              errorMessages: [
                kCellPhoneNullError,
                kCellPhoneInvalidError,
              ],
              validationFunctions: [
                (cellPhone) => validators.isNotEmptyValidator(cellPhone ?? ''),
                (cellPhone) =>
                    validators.isAValidCellPhoneValidator(cellPhone ?? ''),
              ],
              textEditingController: cellPhoneTextController,
              registerStatusErrorInStoreForm:
                  passwordForgotStore.registerCellPhoneStatus,
            ),
          ),
        ),
      );
    });
  }
}
