import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';
import 'package:transparent_image/transparent_image.dart';

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(context: context),
      body: Stack(
        children: <Widget>[
          Center(child: CircularProgressIndicator()),
          Center(
            child: FadeInImage.memoryNetwork(
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
              placeholder: kTransparentImage,
              image:
                  'https://img.r7.com/images/wesley-palmeiras-crb-wesley-triste-09062021204812135?dimensions=771x420',
            ),
          ),
        ],
      ),
    );
  }

  AppBar _appBar({required BuildContext context}) {
    return AppBar(
      leading: InkWell(
        onTap: () => Navigator.of(context).pop(),
        child: Icon(
          Icons.arrow_back,
          size: 36,
        ),
      ),
      actions: [
        Center(
          child: Padding(
            padding: const EdgeInsets.only(right: 14.0),
            child: Text(
              'Esqueci minha senha',
              style: TextStyle(
                color: kSecondaryColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        )
      ],
    );
  }
}
