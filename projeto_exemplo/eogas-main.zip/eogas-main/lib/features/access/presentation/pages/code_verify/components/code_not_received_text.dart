import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/snackbar/snackbar.dart';
import 'package:eogas/core/presentation/mobx_store/in_processing_store.dart';
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get_it/get_it.dart';
import 'package:google_fonts/google_fonts.dart';

class CodeNotReceivedText extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore passwordForgotStore;

  const CodeNotReceivedText({required this.passwordForgotStore});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: _onPressCodeNotReceivedButton,
      child: Row(
        children: [
          Icon(
            FontAwesomeIcons.mobileAlt,
            color: kSecondaryColor,
          ),
          SizedBox(width: 10),
          Text(
            'Não recebi o código',
            style: GoogleFonts.poppins(
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  _onPressCodeNotReceivedButton() {
    FocusScope.of(passwordForgotStore.buildContext!).unfocus();

    GetIt.I.get<InProcessingStore>().registerIsInProcessing(true);

    showBottomSnackBar(
      context: passwordForgotStore.buildContext!,
      durationSeconds: 3,
      content: 'Código RE-enviado para o seu ' +
          (passwordForgotStore.emailIsSelected ? ' email ' : 'celular '),
    );

    passwordForgotStore.registerCodeIsComplete(false);

    Future.delayed(const Duration(seconds: 3), () {
      GetIt.I.get<InProcessingStore>().registerIsInProcessing(false);
    });
  }
}
