abstract class WelcomeBaseContent {
  final String imageURL;
  final String imageText;

  WelcomeBaseContent({
    required this.imageURL,
    required this.imageText,
  });
}
