import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:animated_text_kit/animated_text_kit.dart';

class SplashScreenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/images/brand/launch.png',
                width: MediaQuery.of(context).size.width * .90,
                height: MediaQuery.of(context).size.height * .50,
                fit: BoxFit.fitWidth,
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                'E o Gás??',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 40,
              ),
              GFLoader(
                type: GFLoaderType.circle,
                loaderColorOne: Colors.green.shade100,
                loaderColorTwo: Colors.green.shade300,
                loaderColorThree: Colors.green.shade600,
              ),
              SizedBox(
                height: 40,
              ),
              Container(
                height: 30,
                child: DefaultTextStyle(
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.grey.shade700,
                  ),
                  child: AnimatedTextKit(animatedTexts: [
                    FadeAnimatedText('aguarde'),
                    FadeAnimatedText('preparando tudo'),
                    FadeAnimatedText('para você'),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
