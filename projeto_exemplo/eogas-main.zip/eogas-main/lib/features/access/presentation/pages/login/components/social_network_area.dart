import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/buttons/default_elevated_button.dart';
import 'package:flutter/material.dart';

class SocialNetworkAreaWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 30),
        _buildSocialNetworkAccessText(),
        SizedBox(height: 30),
        _buildSocialNetworkButtons(context),
      ],
    );
  }

  _buildSocialNetworkAccessText() {
    return Center(
      child: Text(
        'ou acesse com redes sociais',
        style: TextStyle(
          fontSize: 14,
        ),
      ),
    );
  }

  Padding _buildSocialNetworkButtons(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          DefaultElevatedButton(
            borderWidth: 0.5,
            borderColor: kSecondaryColor,
            width: MediaQuery.of(context).size.width * .45,
            icon: Image.asset(
              'assets/images/access/facebook_48x48.png',
              width: 48,
            ),
            onPressed: () => Navigator.pushNamed(context, kFacebookAccessRoute),
          ),
          DefaultElevatedButton(
            borderWidth: 0.5,
            borderColor: kSecondaryColor,
            width: MediaQuery.of(context).size.width * .45,
            icon: Image.asset(
              'assets/images/access/google_48x48.png',
              width: 48,
            ),
            onPressed: () => Navigator.pushNamed(context, kGoogleAccessRoute),
          ),
        ],
      ),
    );
  }
}
