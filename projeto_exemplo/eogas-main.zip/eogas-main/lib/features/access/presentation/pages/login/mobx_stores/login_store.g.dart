// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$LoginStore on _LoginStore, Store {
  Computed<bool>? _$formIsValidComputed;

  @override
  bool get formIsValid =>
      (_$formIsValidComputed ??= Computed<bool>(() => super.formIsValid,
              name: '_LoginStore.formIsValid'))
          .value;
  Computed<AutovalidateMode>? _$autoValidateModeFormComputed;

  @override
  AutovalidateMode get autoValidateModeForm =>
      (_$autoValidateModeFormComputed ??= Computed<AutovalidateMode>(
              () => super.autoValidateModeForm,
              name: '_LoginStore.autoValidateModeForm'))
          .value;
  Computed<bool>? _$obscurePasswordTextComputed;

  @override
  bool get obscurePasswordText => (_$obscurePasswordTextComputed ??=
          Computed<bool>(() => super.obscurePasswordText,
              name: '_LoginStore.obscurePasswordText'))
      .value;
  Computed<BuildContext?>? _$buildContextComputed;

  @override
  BuildContext? get buildContext => (_$buildContextComputed ??=
          Computed<BuildContext?>(() => super.buildContext,
              name: '_LoginStore.buildContext'))
      .value;

  final _$_emailIsValidAtom = Atom(name: '_LoginStore._emailIsValid');

  @override
  bool get _emailIsValid {
    _$_emailIsValidAtom.reportRead();
    return super._emailIsValid;
  }

  @override
  set _emailIsValid(bool value) {
    _$_emailIsValidAtom.reportWrite(value, super._emailIsValid, () {
      super._emailIsValid = value;
    });
  }

  final _$_passwordIsValidAtom = Atom(name: '_LoginStore._passwordIsValid');

  @override
  bool get _passwordIsValid {
    _$_passwordIsValidAtom.reportRead();
    return super._passwordIsValid;
  }

  @override
  set _passwordIsValid(bool value) {
    _$_passwordIsValidAtom.reportWrite(value, super._passwordIsValid, () {
      super._passwordIsValid = value;
    });
  }

  final _$_autoValidateModeFormAtom =
      Atom(name: '_LoginStore._autoValidateModeForm');

  @override
  AutovalidateMode get _autoValidateModeForm {
    _$_autoValidateModeFormAtom.reportRead();
    return super._autoValidateModeForm;
  }

  @override
  set _autoValidateModeForm(AutovalidateMode value) {
    _$_autoValidateModeFormAtom.reportWrite(value, super._autoValidateModeForm,
        () {
      super._autoValidateModeForm = value;
    });
  }

  final _$formKeyAtom = Atom(name: '_LoginStore.formKey');

  @override
  GlobalKey<FormState> get formKey {
    _$formKeyAtom.reportRead();
    return super.formKey;
  }

  @override
  set formKey(GlobalKey<FormState> value) {
    _$formKeyAtom.reportWrite(value, super.formKey, () {
      super.formKey = value;
    });
  }

  final _$_obscurePasswordTextAtom =
      Atom(name: '_LoginStore._obscurePasswordText');

  @override
  bool get _obscurePasswordText {
    _$_obscurePasswordTextAtom.reportRead();
    return super._obscurePasswordText;
  }

  @override
  set _obscurePasswordText(bool value) {
    _$_obscurePasswordTextAtom.reportWrite(value, super._obscurePasswordText,
        () {
      super._obscurePasswordText = value;
    });
  }

  final _$_buildContextAtom = Atom(name: '_LoginStore._buildContext');

  @override
  BuildContext? get _buildContext {
    _$_buildContextAtom.reportRead();
    return super._buildContext;
  }

  @override
  set _buildContext(BuildContext? value) {
    _$_buildContextAtom.reportWrite(value, super._buildContext, () {
      super._buildContext = value;
    });
  }

  final _$_LoginStoreActionController = ActionController(name: '_LoginStore');

  @override
  dynamic registerEmailStatus(bool value) {
    final _$actionInfo = _$_LoginStoreActionController.startAction(
        name: '_LoginStore.registerEmailStatus');
    try {
      return super.registerEmailStatus(value);
    } finally {
      _$_LoginStoreActionController.endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerPasswordStatus(bool value) {
    final _$actionInfo = _$_LoginStoreActionController.startAction(
        name: '_LoginStore.registerPasswordStatus');
    try {
      return super.registerPasswordStatus(value);
    } finally {
      _$_LoginStoreActionController.endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerAutoValidateModeForm({required AutovalidateMode value}) {
    final _$actionInfo = _$_LoginStoreActionController.startAction(
        name: '_LoginStore.registerAutoValidateModeForm');
    try {
      return super.registerAutoValidateModeForm(value: value);
    } finally {
      _$_LoginStoreActionController.endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerObscurePasswordText({required bool value}) {
    final _$actionInfo = _$_LoginStoreActionController.startAction(
        name: '_LoginStore.registerObscurePasswordText');
    try {
      return super.registerObscurePasswordText(value: value);
    } finally {
      _$_LoginStoreActionController.endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerBuildContext({required BuildContext value}) {
    final _$actionInfo = _$_LoginStoreActionController.startAction(
        name: '_LoginStore.registerBuildContext');
    try {
      return super.registerBuildContext(value: value);
    } finally {
      _$_LoginStoreActionController.endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    return '''
formKey: ${formKey},
formIsValid: ${formIsValid},
autoValidateModeForm: ${autoValidateModeForm},
obscurePasswordText: ${obscurePasswordText},
buildContext: ${buildContext}
    ''';
  }
}
