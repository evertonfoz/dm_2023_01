import 'base.dart';

class SecondWelcomeContentPage extends WelcomeBaseContent {
  SecondWelcomeContentPage()
      : super(
          imageURL: "assets/images/welcome/02.png",
          imageText:
              "Nosso objetivo é ajudar você no controle do consumo de seu gás e na previsão para nova compra",
        );
}
