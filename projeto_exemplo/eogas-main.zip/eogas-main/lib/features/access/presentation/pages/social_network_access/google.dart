import 'package:flutter/material.dart';
import 'package:transparent_image/transparent_image.dart';

class GoogleAccessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Stack(
        children: <Widget>[
          Center(child: CircularProgressIndicator()),
          Center(
            child: FadeInImage.memoryNetwork(
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
              placeholder: kTransparentImage,
              image:
                  'https://diariodorio.com/wp-content/uploads/2019/10/WhatsApp-Image-2019-10-24-at-09.14.16.jpeg',
            ),
          ),
        ],
      ),
    );
  }
}
