import 'package:flutter/material.dart';

class WelcomeContent extends StatelessWidget {
  final String text, image;

  const WelcomeContent({
    required this.text,
    required this.image,
  });

  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Expanded(
          flex: 5,
          child: Image.asset(
            image,
            width: MediaQuery.of(context).size.width * .90,
            height: MediaQuery.of(context).size.height * .50,
            fit: BoxFit.fitWidth,
          ),
        ),
        SizedBox(height: 30),
        Expanded(
          flex: 2,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
