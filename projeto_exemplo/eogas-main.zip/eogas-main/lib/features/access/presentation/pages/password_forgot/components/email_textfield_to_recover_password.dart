import 'package:eogas/core/presentation/business/text_validators.dart'
    as validators;
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:eogas/features/access/presentation/pages/constants.dart';
import 'package:eogas/features/access/presentation/pages/password_forgot/components/textfield_to_means_to_recover_password.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

class EmailTextFieldToRecoverPassword extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore passwordForgotStore;
  final TextEditingController emailTextController;

  const EmailTextFieldToRecoverPassword({
    required this.passwordForgotStore,
    required this.emailTextController,
  });

  @override
  Widget build(BuildContext context) {
    return Observer(builder: (_) {
      return Visibility(
        visible: passwordForgotStore.emailIsSelected,
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Form(
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: TextFieldToMeansToRecoverPasswordWidget(
                textInputType: TextInputType.emailAddress,
                text: 'Insira seu e-mail',
                errorMessages: [
                  kEmailNullError,
                  kEmailInvalidError,
                ],
                validationFunctions: [
                  (value) => validators.isNotEmptyValidator(value ?? ''),
                  (value) => validators.isAValidEmailValidator(value ?? ''),
                ],
                textEditingController: emailTextController,
                registerStatusErrorInStoreForm:
                    passwordForgotStore.registerEmailStatus),
          ),
        ),
      );
    });
  }
}
