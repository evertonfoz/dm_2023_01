import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';

class EOGasTitle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(
      "E O GÁS??",
      style: TextStyle(
        fontSize: 62,
        color: kSecondaryColor,
        fontWeight: FontWeight.bold,
      ),
    );
  }
}
