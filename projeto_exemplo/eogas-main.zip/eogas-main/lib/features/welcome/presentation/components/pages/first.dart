import 'base.dart';

class FirstWelcomeContentPage extends WelcomeBaseContent {
  FirstWelcomeContentPage()
      : super(
          imageURL: "assets/images/welcome/01.png",
          imageText: "Bem-vindo(a) ao 'E o Gás??'",
        );
}
