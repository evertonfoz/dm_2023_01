import 'package:eogas/core/constants.dart';
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:google_fonts/google_fonts.dart';

class MeansToRecoverPasswordWidget extends StatelessWidget {
  final PasswordForgotAndCodeVerifyStore passwordForgotStore;

  const MeansToRecoverPasswordWidget({required this.passwordForgotStore});

  @override
  Widget build(BuildContext context) {
    return Observer(builder: (_) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _MeansToRecoverPasswordWidget(
            text: 'E-mail',
            selected: passwordForgotStore.emailIsSelected,
            onTap: () {
              passwordForgotStore.registerChangeOfMeansOfRecovery();
            },
          ),
          SizedBox(width: 30),
          _MeansToRecoverPasswordWidget(
            text: 'Celular',
            selected: passwordForgotStore.cellPhoneIsSelected,
            onTap: () {
              passwordForgotStore.registerChangeOfMeansOfRecovery();
            },
          ),
        ],
      );
    });
  }
}

class _MeansToRecoverPasswordWidget extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;

  const _MeansToRecoverPasswordWidget({
    required this.text,
    this.selected = true,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            text,
            style: GoogleFonts.poppins(
              color:
                  selected ? kSecondaryColor : kSecondaryColor.withOpacity(0.3),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Visibility(
            visible: selected,
            child: Container(
              width: 50,
              child: const Divider(
                color: kSecondaryColor,
                height: 25,
                thickness: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
