import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';

class AppBarAccessWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: InkWell(
        onTap: () {
          if (FocusScope.of(context).isFirstFocus) {
            FocusScope.of(context).unfocus();
          }

          Navigator.of(context).pop();
        },
        child: Icon(
          Icons.arrow_back,
          size: 36,
        ),
      ),
      actions: [
        Center(
          child: Padding(
            padding: const EdgeInsets.only(right: 14.0),
            child: InkWell(
              onTap: () => Navigator.pushNamed(context, kPasswordForgot),
              child: Text(
                'Esqueci minha senha',
                style: TextStyle(
                  color: kSecondaryColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        )
      ],
    );
  }
}
