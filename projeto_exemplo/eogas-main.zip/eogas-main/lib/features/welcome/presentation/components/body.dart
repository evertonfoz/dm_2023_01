import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/brand/title_e_o_gas.dart';
import 'package:eogas/core/presentation/components/buttons/default_text_button.dart';
import 'package:eogas/features/welcome/presentation/components/pages/base.dart';
import 'package:eogas/features/welcome/presentation/components/pages/first.dart';
import 'package:eogas/features/welcome/presentation/components/pages/second.dart';
import 'package:eogas/features/welcome/presentation/components/pages/third.dart';
import 'package:flutter/material.dart';

import 'content.dart';

const kLastWelcomePageNumber = 2;

class WelcomeBody extends StatefulWidget {
  @override
  _WelcomeBodyState createState() => _WelcomeBodyState();
}

class _WelcomeBodyState extends State<WelcomeBody> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late List<WelcomeBaseContent> _welcomeData;

  @override
  void initState() {
    super.initState();
    _initializeWelcomeData();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  _initializeWelcomeData() {
    _welcomeData = [
      FirstWelcomeContentPage(),
      SecondWelcomeContentPage(),
      ThirdWelcomeContentPage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      // mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        SizedBox(height: 30),
        EOGasTitle(),
        SizedBox(height: 30),
        Expanded(
          flex: 15,
          child: _imageAndImageText(),
        ),
        Expanded(
          flex: 3,
          child: _dots(),
        ),
        Expanded(
          flex: 2,
          child: _navigationButtons(),
        ),
        // Expanded(child: SizedBox(height: 30)),
      ],
    );
  }

  _imageAndImageText() {
    return PageView.builder(
      controller: _pageController,
      itemCount: _welcomeData.length,
      onPageChanged: (page) {
        setState(() {
          _currentPage = page;
        });
      },
      itemBuilder: (context, index) => WelcomeContent(
        image: _welcomeData[index].imageURL,
        text: _welcomeData[index].imageText,
      ),
    );
  }

  _navigationButtons() {
    List<Widget> _buttons = [];
    if (_currentPage != kLastWelcomePageNumber) {
      _buttons.add(
        DefaultTextButton(
          text: "Pular",
          onPressed: () => Navigator.of(context).pushNamed(kAccessPageRoute),
        ),
      );
      _buttons.add(
        DefaultTextButton(
          text: "Próxima",
          onPressed: () {
            setState(() {
              _currentPage++;
            });
            _animateToCurrentPage();
          },
        ),
      );
    } else {
      _buttons.add(
        DefaultTextButton(
          text: "Começar",
          onPressed: () => Navigator.of(context).pushNamed(kAccessPageRoute),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
          mainAxisAlignment: _currentPage != kLastWelcomePageNumber
              ? MainAxisAlignment.spaceBetween
              : MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: _buttons),
    );
  }

  void _animateToCurrentPage() {
    _pageController.animateToPage(
      _currentPage,
      duration: Duration(microseconds: 500),
      curve: Curves.easeInToLinear,
    );
  }

  _dots() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: List.generate(
            _welcomeData.length, // Tiro a tela de acesso
            (index) => _buildDot(index: index),
          ),
        ),
        SizedBox(height: 30),
      ],
    );
  }

  AnimatedContainer _buildDot({required int index}) {
    return AnimatedContainer(
      duration: kAnimationDuration,
      margin: EdgeInsets.only(right: 5),
      height: 6,
      width: _currentPage == index ? 20 : 6,
      decoration: BoxDecoration(
        color: _currentPage == index ? kThirdColor : kSecondaryColor,
        borderRadius: BorderRadius.circular(3),
      ),
    );
  }
}
