import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/mobx_store/in_processing_store.dart';
import 'package:eogas/features/splashscreen/presentation/pages/splashscreen.dart';
import 'package:eogas/features/welcome/presentation/pages/welcome.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:responsive_framework/responsive_framework.dart';

import 'core/presentation/router_transition/router.dart';
import 'core/presentation/theme.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
  ));

  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitDown, DeviceOrientation.portraitUp]);

  GetIt.I.registerSingleton<InProcessingStore>(InProcessingStore());

  runApp(EOGasApp());
}

class EOGasApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _withoutFuture();
  }

  // ignore: unused_element
  _withoutFuture() {
    return MaterialApp(
      // color: Colors.red,
      debugShowCheckedModeBanner: false,
      onGenerateRoute: RouterTransition.generateRoute,
      title: 'E o Gás??',
      theme: theme(),
      builder: (context, widget) => ResponsiveWrapper.builder(
        ClampingScrollWrapper.builder(context, widget!),
        maxWidth: 600,
        minWidth: 450,
        defaultScale: true,
        breakpoints: [
          ResponsiveBreakpoint.resize(450, name: MOBILE),
          ResponsiveBreakpoint.autoScale(600, name: TABLET),
        ],
        backgroundColor: kSecondaryColor,
      ),
      home: WelcomePage(),
    );
  }

  _withFuture() {
    return FutureBuilder(
      future: Future.delayed(Duration(seconds: 3)),
      builder: (context, AsyncSnapshot snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return MaterialApp(
            // color: Colors.red,
            theme: theme(),
            debugShowCheckedModeBanner: false,
            home: SplashScreenPage(),
          );
        }
        return MaterialApp(
          color: Colors.red,
          debugShowCheckedModeBanner: false,
          onGenerateRoute: RouterTransition.generateRoute,
          title: 'E o Gás??',
          theme: theme(),
          builder: (context, widget) => ResponsiveWrapper.builder(
            ClampingScrollWrapper.builder(context, widget!),
            maxWidth: 600,
            minWidth: 450,
            defaultScale: true,
            breakpoints: [
              ResponsiveBreakpoint.resize(450, name: MOBILE),
              ResponsiveBreakpoint.autoScale(600, name: TABLET),
            ],
            backgroundColor: kSecondaryColor,
          ),
          home: WelcomePage(),
        );
      },
    );
  }
}
