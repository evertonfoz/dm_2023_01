import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class TextFormFieldEOG extends StatefulWidget {
  final Function(String?)? onSaved;
  final List<String> errorMessages;
  final List<Function(String?)> validationFunctions;
  final int errorMaxLines;
  final bool obscureText;
  final List<IconData>? aditionalSufixIcons;
  final VoidCallback? onPressAditionalSufixIcon;
  final TextInputType textInputType;
  final TextInputAction textInputAction;
  final Function(bool)? registerInStoreForm;
  final TextEditingController? textEditingController;
  final TextInputFormatter? textInputFormatter;
  final String? prefixText;

  const TextFormFieldEOG({
    required this.onSaved,
    required this.errorMessages,
    required this.validationFunctions,
    this.errorMaxLines: 1,
    this.obscureText: false,
    this.aditionalSufixIcons,
    this.onPressAditionalSufixIcon,
    this.textInputType: TextInputType.text,
    this.textInputAction: TextInputAction.done,
    this.registerInStoreForm,
    this.textEditingController,
    this.textInputFormatter,
    this.prefixText,
  });

  @override
  _TextFormFieldEOGState createState() => _TextFormFieldEOGState();
}

class _TextFormFieldEOGState extends State<TextFormFieldEOG> {
  bool? hasError;
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = widget.textEditingController ?? TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      inputFormatters:
          widget.textInputFormatter != null ? [widget.textInputFormatter!] : [],
      textInputAction: widget.textInputAction,
      keyboardType: widget.textInputType,
      // onSaved: (value) => print('OnSaved'),
      // onSaved: (newValue) => widget.onSaved(newValue),
      onChanged: (value) {
        setState(() {
          hasError = (value.isNotEmpty) ? false : null;
        });
        for (var i = 0; i < widget.validationFunctions.length; i++) {
          if (!widget.validationFunctions[i](value)) {
            setState(() {
              hasError = true;
            });
          }
        }

        widget.registerInStoreForm!(!hasError!);

        return null;
      },
      validator: (value) {
        for (var i = 0; i < widget.validationFunctions.length; i++) {
          if (!widget.validationFunctions[i](value)) {
            return widget.errorMessages[i];
          }
        }
        return null;
      },
      // onFieldSubmitted: (value) => print('onFieldSubmitted => $value'),
      controller: _controller,
      textAlign: TextAlign.left,
      obscureText: widget.obscureText,
      decoration: InputDecoration(
        prefixText: widget.prefixText ?? '',
        suffixIcon: _buildSufixIcon(),
        fillColor: kTextFieldFillColor.shade100,
        filled: true,
        errorMaxLines: widget.errorMaxLines,
        contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
      ),
    );
  }

  _buildSufixIcon() {
    List<Widget> sufixIcons = [];
    if (hasError == null) {
      sufixIcons.add(Container(height: 0, width: 0));
    } else {
      if (!hasError!) {
        sufixIcons.add(Icon(
          Icons.check,
          color: Colors.green,
        ));
        _addAditionalSufixIcon(sufixIcons, Colors.green);
      }
      if (hasError! && _controller.text.isNotEmpty) {
        sufixIcons.add(Icon(
          Icons.error,
          color: Colors.red,
        ));
        _addAditionalSufixIcon(sufixIcons, Colors.red);
      }
    }
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: sufixIcons),
    );
  }

  void _addAditionalSufixIcon(List<Widget> sufixIcons, Color color) {
    if (widget.aditionalSufixIcons != null) {
      sufixIcons.add(SizedBox(width: 8));
      sufixIcons.add(InkWell(
        onTap: () => widget.onPressAditionalSufixIcon == null
            ? null
            : widget.onPressAditionalSufixIcon!(),
        child: FaIcon(
          widget.aditionalSufixIcons![widget.obscureText ? 0 : 1],
          color: color,
        ),
      ));
    }
  }
}
