import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';

class BrandImage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Image.asset(
      kBrandImage,
      width: MediaQuery.of(context).size.width * .90,
      height: MediaQuery.of(context).size.height * .50,
      fit: BoxFit.fitWidth,
    );
  }
}
