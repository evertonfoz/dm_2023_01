import 'package:eogas/core/constants.dart';
import 'package:eogas/core/presentation/components/buttons/default_elevated_button.dart';
import 'package:flutter/material.dart';

class AccessButtonWidget extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;

  const AccessButtonWidget({
    required this.onPressed,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0),
      child: Column(
        children: [
          SizedBox(height: 20),
          ConstrainedBox(
            constraints:
                BoxConstraints.tightFor(width: double.infinity, height: 50),
            child: DefaultElevatedButton(
              buttonColor: kSecondaryColor,
              textColor: kPrimaryColor,
              text: text,
              onPressed: onPressed,
            ),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
