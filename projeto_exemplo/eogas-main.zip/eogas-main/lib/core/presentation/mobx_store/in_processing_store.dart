import 'package:mobx/mobx.dart';

part 'in_processing_store.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner build --delete-conflicting-outputs
/// flutter packages pub run build_runner watch

class InProcessingStore = _InProcessingStore with _$InProcessingStore;

abstract class _InProcessingStore with Store {
  @observable
  bool _isInProcessing = false;

  @computed
  bool get isInProcessing => _isInProcessing;

  @action
  registerIsInProcessing(bool value) {
    _isInProcessing = value;
  }
}
