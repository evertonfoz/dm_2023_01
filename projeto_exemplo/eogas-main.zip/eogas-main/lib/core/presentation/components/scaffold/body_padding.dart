import 'package:flutter/material.dart';

class BodyPaddingWidget extends StatelessWidget {
  final Widget child;
  final double left;

  const BodyPaddingWidget({
    required this.child,
    this.left: 12,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: left, right: 12, top: 8, bottom: 8),
        child: child);
  }
}
