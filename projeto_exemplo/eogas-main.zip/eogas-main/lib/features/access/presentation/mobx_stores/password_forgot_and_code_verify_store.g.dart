// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'password_forgot_and_code_verify_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$PasswordForgotAndCodeVerifyStore
    on _PasswordForgotAndCodeVerifyStore, Store {
  Computed<bool>? _$emailIsSelectedComputed;

  @override
  bool get emailIsSelected =>
      (_$emailIsSelectedComputed ??= Computed<bool>(() => super.emailIsSelected,
              name: '_PasswordForgotAndCodeVerifyStore.emailIsSelected'))
          .value;
  Computed<bool>? _$cellPhoneIsSelectedComputed;

  @override
  bool get cellPhoneIsSelected => (_$cellPhoneIsSelectedComputed ??=
          Computed<bool>(() => super.cellPhoneIsSelected,
              name: '_PasswordForgotAndCodeVerifyStore.cellPhoneIsSelected'))
      .value;
  Computed<bool>? _$formIsValidComputed;

  @override
  bool get formIsValid =>
      (_$formIsValidComputed ??= Computed<bool>(() => super.formIsValid,
              name: '_PasswordForgotAndCodeVerifyStore.formIsValid'))
          .value;
  Computed<BuildContext?>? _$buildContextComputed;

  @override
  BuildContext? get buildContext => (_$buildContextComputed ??=
          Computed<BuildContext?>(() => super.buildContext,
              name: '_PasswordForgotAndCodeVerifyStore.buildContext'))
      .value;
  Computed<String>? _$codeComputed;

  @override
  String get code => (_$codeComputed ??= Computed<String>(() => super.code,
          name: '_PasswordForgotAndCodeVerifyStore.code'))
      .value;
  Computed<String>? _$emailComputed;

  @override
  String get email => (_$emailComputed ??= Computed<String>(() => super.email,
          name: '_PasswordForgotAndCodeVerifyStore.email'))
      .value;
  Computed<String>? _$cellPhoneComputed;

  @override
  String get cellPhone =>
      (_$cellPhoneComputed ??= Computed<String>(() => super.cellPhone,
              name: '_PasswordForgotAndCodeVerifyStore.cellPhone'))
          .value;
  Computed<bool>? _$obscureCodeComputed;

  @override
  bool get obscureCode =>
      (_$obscureCodeComputed ??= Computed<bool>(() => super.obscureCode,
              name: '_PasswordForgotAndCodeVerifyStore.obscureCode'))
          .value;
  Computed<bool>? _$codeIsCompleteComputed;

  @override
  bool get codeIsComplete =>
      (_$codeIsCompleteComputed ??= Computed<bool>(() => super.codeIsComplete,
              name: '_PasswordForgotAndCodeVerifyStore.codeIsComplete'))
          .value;

  final _$_emailIsSelectedAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._emailIsSelected');

  @override
  bool get _emailIsSelected {
    _$_emailIsSelectedAtom.reportRead();
    return super._emailIsSelected;
  }

  @override
  set _emailIsSelected(bool value) {
    _$_emailIsSelectedAtom.reportWrite(value, super._emailIsSelected, () {
      super._emailIsSelected = value;
    });
  }

  final _$_cellPhoneIsSelectedAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._cellPhoneIsSelected');

  @override
  bool get _cellPhoneIsSelected {
    _$_cellPhoneIsSelectedAtom.reportRead();
    return super._cellPhoneIsSelected;
  }

  @override
  set _cellPhoneIsSelected(bool value) {
    _$_cellPhoneIsSelectedAtom.reportWrite(value, super._cellPhoneIsSelected,
        () {
      super._cellPhoneIsSelected = value;
    });
  }

  final _$_emailIsValidAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._emailIsValid');

  @override
  bool get _emailIsValid {
    _$_emailIsValidAtom.reportRead();
    return super._emailIsValid;
  }

  @override
  set _emailIsValid(bool value) {
    _$_emailIsValidAtom.reportWrite(value, super._emailIsValid, () {
      super._emailIsValid = value;
    });
  }

  final _$_cellPhoneIsValidAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._cellPhoneIsValid');

  @override
  bool get _cellPhoneIsValid {
    _$_cellPhoneIsValidAtom.reportRead();
    return super._cellPhoneIsValid;
  }

  @override
  set _cellPhoneIsValid(bool value) {
    _$_cellPhoneIsValidAtom.reportWrite(value, super._cellPhoneIsValid, () {
      super._cellPhoneIsValid = value;
    });
  }

  final _$formKeyAtom = Atom(name: '_PasswordForgotAndCodeVerifyStore.formKey');

  @override
  GlobalKey<FormState> get formKey {
    _$formKeyAtom.reportRead();
    return super.formKey;
  }

  @override
  set formKey(GlobalKey<FormState> value) {
    _$formKeyAtom.reportWrite(value, super.formKey, () {
      super.formKey = value;
    });
  }

  final _$_buildContextAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._buildContext');

  @override
  BuildContext? get _buildContext {
    _$_buildContextAtom.reportRead();
    return super._buildContext;
  }

  @override
  set _buildContext(BuildContext? value) {
    _$_buildContextAtom.reportWrite(value, super._buildContext, () {
      super._buildContext = value;
    });
  }

  final _$_codeAtom = Atom(name: '_PasswordForgotAndCodeVerifyStore._code');

  @override
  String get _code {
    _$_codeAtom.reportRead();
    return super._code;
  }

  @override
  set _code(String value) {
    _$_codeAtom.reportWrite(value, super._code, () {
      super._code = value;
    });
  }

  final _$_emailAtom = Atom(name: '_PasswordForgotAndCodeVerifyStore._email');

  @override
  String get _email {
    _$_emailAtom.reportRead();
    return super._email;
  }

  @override
  set _email(String value) {
    _$_emailAtom.reportWrite(value, super._email, () {
      super._email = value;
    });
  }

  final _$_cellPhoneAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._cellPhone');

  @override
  String get _cellPhone {
    _$_cellPhoneAtom.reportRead();
    return super._cellPhone;
  }

  @override
  set _cellPhone(String value) {
    _$_cellPhoneAtom.reportWrite(value, super._cellPhone, () {
      super._cellPhone = value;
    });
  }

  final _$_codeIsCompleteAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._codeIsComplete');

  @override
  bool get _codeIsComplete {
    _$_codeIsCompleteAtom.reportRead();
    return super._codeIsComplete;
  }

  @override
  set _codeIsComplete(bool value) {
    _$_codeIsCompleteAtom.reportWrite(value, super._codeIsComplete, () {
      super._codeIsComplete = value;
    });
  }

  final _$_obscureCodeAtom =
      Atom(name: '_PasswordForgotAndCodeVerifyStore._obscureCode');

  @override
  bool get _obscureCode {
    _$_obscureCodeAtom.reportRead();
    return super._obscureCode;
  }

  @override
  set _obscureCode(bool value) {
    _$_obscureCodeAtom.reportWrite(value, super._obscureCode, () {
      super._obscureCode = value;
    });
  }

  final _$_PasswordForgotAndCodeVerifyStoreActionController =
      ActionController(name: '_PasswordForgotAndCodeVerifyStore');

  @override
  dynamic registerEmailStatus(bool value) {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name: '_PasswordForgotAndCodeVerifyStore.registerEmailStatus');
    try {
      return super.registerEmailStatus(value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerCellPhoneStatus(bool value) {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name: '_PasswordForgotAndCodeVerifyStore.registerCellPhoneStatus');
    try {
      return super.registerCellPhoneStatus(value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerBuildContext({required BuildContext value}) {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name: '_PasswordForgotAndCodeVerifyStore.registerBuildContext');
    try {
      return super.registerBuildContext(value: value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerChangeOfMeansOfRecovery() {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name:
                '_PasswordForgotAndCodeVerifyStore.registerChangeOfMeansOfRecovery');
    try {
      return super.registerChangeOfMeansOfRecovery();
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerCode(String value) {
    final _$actionInfo = _$_PasswordForgotAndCodeVerifyStoreActionController
        .startAction(name: '_PasswordForgotAndCodeVerifyStore.registerCode');
    try {
      return super.registerCode(value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerEmail(String value) {
    final _$actionInfo = _$_PasswordForgotAndCodeVerifyStoreActionController
        .startAction(name: '_PasswordForgotAndCodeVerifyStore.registerEmail');
    try {
      return super.registerEmail(value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerCellPhone(String value) {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name: '_PasswordForgotAndCodeVerifyStore.registerCellPhone');
    try {
      return super.registerCellPhone(value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerCodeIsComplete(bool value) {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name: '_PasswordForgotAndCodeVerifyStore.registerCodeIsComplete');
    try {
      return super.registerCodeIsComplete(value);
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  dynamic registerTurnObscureCode() {
    final _$actionInfo =
        _$_PasswordForgotAndCodeVerifyStoreActionController.startAction(
            name: '_PasswordForgotAndCodeVerifyStore.registerTurnObscureCode');
    try {
      return super.registerTurnObscureCode();
    } finally {
      _$_PasswordForgotAndCodeVerifyStoreActionController
          .endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    return '''
formKey: ${formKey},
emailIsSelected: ${emailIsSelected},
cellPhoneIsSelected: ${cellPhoneIsSelected},
formIsValid: ${formIsValid},
buildContext: ${buildContext},
code: ${code},
email: ${email},
cellPhone: ${cellPhone},
obscureCode: ${obscureCode},
codeIsComplete: ${codeIsComplete}
    ''';
  }
}
