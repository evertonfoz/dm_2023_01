import 'base.dart';

class ThirdWelcomeContentPage extends WelcomeBaseContent {
  ThirdWelcomeContentPage()
      : super(
          imageURL: "assets/images/welcome/03.png",
          imageText: "Você verá que poderemos lhe ajudar",
        );
}
