import 'dart:async';

import 'package:eogas/core/constants.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class PinCodeToRecoverPassword extends StatefulWidget {
  final Function(bool) validator;
  final bool? obscureCode;

  const PinCodeToRecoverPassword({
    required this.validator,
    this.obscureCode = true,
  });

  @override
  _PinCodeVerificationScreenState createState() =>
      _PinCodeVerificationScreenState();
}

class _PinCodeVerificationScreenState extends State<PinCodeToRecoverPassword> {
  TextEditingController textEditingController = TextEditingController();

  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  // bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    errorController = StreamController<ErrorAnimationType>();
  }

  @override
  void dispose() {
    errorController!.close();
    super.dispose();
  }

  // // snackBar Widget
  // snackBar(String? message) {
  //   return ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(
  //       content: Text(message!),
  //       duration: Duration(seconds: 2),
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        height: 80,
        width: MediaQuery.of(context).size.width,
        child: ListView(
          children: <Widget>[
            Form(
              key: formKey,
              autovalidateMode: AutovalidateMode.disabled,
              child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 8.0, horizontal: 30),
                  child: Theme(
                    data: ThemeData(
                      inputDecorationTheme: InputDecorationTheme(
                        focusedErrorBorder: null,
                      ),
                    ),
                    child: PinCodeTextField(
                      textStyle: GoogleFonts.poppins(color: kSecondaryColor),
                      appContext: context,
                      pastedTextStyle: GoogleFonts.poppins(
                        color: Colors.green.shade600,
                        fontWeight: FontWeight.bold,
                      ),
                      length: 6,
                      obscureText: widget.obscureCode!,
                      obscuringCharacter: '*',
                      obscuringWidget: widget.obscureCode!
                          ? Container(
                              height: 52,
                              width: 64,
                              color: kThirdColor,
                              child: Padding(
                                padding: const EdgeInsets.all(2.0),
                                child: Opacity(
                                  opacity: 0.5,
                                  child: Image.asset(
                                    'assets/images/brand/brand_512x360.png',
                                    width: 38,
                                    height: 38,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ),
                            )
                          : null,
                      blinkWhenObscuring: true,
                      animationType: AnimationType.fade,
                      validator: (v) {
                        Future.delayed(const Duration(milliseconds: 100), () {
                          widget.validator(v!.length == 6);
                        });
                        return null;
                      },
                      pinTheme: PinTheme(
                        shape: PinCodeFieldShape.box,
                        borderRadius: BorderRadius.circular(5),
                        fieldHeight: 52,
                        fieldWidth: 54,
                        activeColor: kThirdColor,
                        activeFillColor: kPrimaryColor,
                        inactiveFillColor: Colors.grey.shade300,
                        inactiveColor: Colors.grey.shade500,
                        selectedColor: kThirdColor,
                        selectedFillColor: kPrimaryColor,
                      ),
                      cursorColor: Colors.black,
                      animationDuration: Duration(milliseconds: 300),
                      enableActiveFill: true,
                      errorAnimationController: errorController,
                      controller: textEditingController,
                      keyboardType: TextInputType.number,
                      boxShadows: [
                        BoxShadow(
                          offset: Offset(0, 1),
                          color: Colors.black12,
                          blurRadius: 10,
                        )
                      ],
                      onCompleted: (v) {
                        // print("Completed");
                      },
                      // onTap: () {
                      //   print("Pressed");
                      // },
                      onChanged: (value) {
                        // print('value $value');
                        // setState(() {
                        currentText = value;
                        // });
                      },
                      beforeTextPaste: (text) {
                        print("Allowing to paste $text");
                        //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                        //but you can show anything you want here, like your pop up saying wrong paste format or etc
                        return true;
                      },
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
