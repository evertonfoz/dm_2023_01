import 'package:flutter/material.dart';
import 'package:mobx/mobx.dart';

part 'login_store.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner build --delete-conflicting-outputs
/// flutter packages pub run build_runner watch

class LoginStore = _LoginStore with _$LoginStore;

abstract class _LoginStore with Store {
  @observable
  bool _emailIsValid = false;

  @observable
  bool _passwordIsValid = false;

  @observable
  AutovalidateMode _autoValidateModeForm = AutovalidateMode.onUserInteraction;

  @observable
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @observable
  bool _obscurePasswordText = true;

  @observable
  BuildContext? _buildContext;

  @computed
  bool get formIsValid => _emailIsValid && _passwordIsValid;

  @computed
  AutovalidateMode get autoValidateModeForm => _autoValidateModeForm;

  @computed
  bool get obscurePasswordText => _obscurePasswordText;

  @computed
  BuildContext? get buildContext => _buildContext;

  @action
  registerEmailStatus(bool value) {
    _emailIsValid = value;
  }

  @action
  registerPasswordStatus(bool value) {
    _passwordIsValid = value;
  }

  @action
  registerAutoValidateModeForm({required AutovalidateMode value}) {
    _autoValidateModeForm = value;
  }

  @action
  registerObscurePasswordText({required bool value}) {
    _obscurePasswordText = value;
  }

  @action
  registerBuildContext({required BuildContext value}) {
    _buildContext = value;
  }
}
