import 'package:eogas/core/presentation/components/text/text.dart';
import 'package:eogas/core/presentation/components/textformfield/textformfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TextFieldToMeansToRecoverPasswordWidget extends StatelessWidget {
  final String text;
  final List<String>? errorMessages;
  final List<Function(String?)>? validationFunctions;
  final TextEditingController textEditingController;
  final Function(bool) registerStatusErrorInStoreForm;
  final TextInputType textInputType;
  final TextInputFormatter? textInputFormatter;
  final String? prefixText;

  const TextFieldToMeansToRecoverPasswordWidget({
    required this.text,
    this.errorMessages,
    this.validationFunctions,
    required this.textEditingController,
    required this.registerStatusErrorInStoreForm,
    this.textInputType = TextInputType.text,
    this.textInputFormatter,
    this.prefixText,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextEOG(
          text: text,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        SizedBox(height: 10),
        TextFormFieldEOG(
            prefixText: prefixText,
            textInputFormatter: textInputFormatter,
            textEditingController: textEditingController,
            textInputType: textInputType,
            textInputAction: TextInputAction.done,
            errorMessages: errorMessages ?? [],
            validationFunctions: validationFunctions ?? [],
            onSaved: (newValue) => textEditingController.text = newValue ?? '',
            registerInStoreForm: registerStatusErrorInStoreForm),
      ],
    );
  }
}
