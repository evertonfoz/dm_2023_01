const String kEmailNullError = 'Por favor, informe e-mail';
const String kEmailInvalidError = 'Por favor, informe um e-mail válido';

const String kPasswordNullError = 'Por favor, informe a senha';
const String kPasswordInvalidError =
    'Mínimo 8 caracteres, sendo necessário: 1 letra maiuscula, 1 minúscula, 1 número e 1 símbolo';

const String kCellPhoneNullError = 'Por favor, informe a senha';
const String kCellPhoneInvalidError = 'É preciso o DDD e seu número';
