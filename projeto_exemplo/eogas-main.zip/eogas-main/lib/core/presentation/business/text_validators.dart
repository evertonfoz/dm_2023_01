bool isNotEmptyValidator(String value) {
  return value.isNotEmpty;
}

bool isAValidEmailValidator(String value) {
  if (!isNotEmptyValidator(value)) return false;

  String pattern = r"^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+";
//  r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  RegExp regex = new RegExp(pattern);
  return (regex.hasMatch(value));
}

bool isAValidPasswordValidator(String password) {
  if (password.length < 8) return false;
  if (!password.contains(RegExp(r"[a-z]"))) return false;
  if (!password.contains(RegExp(r"[A-Z]"))) return false;
  if (!password.contains(RegExp(r"[0-9]"))) return false;
  if (!password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) return false;
  return true;
}

bool isAValidCellPhoneValidator(String cellPhone) {
  return removeSpecialCaracteres(value: cellPhone, regExp: r'[\+\- ()]')
          .length ==
      11;
}

String removeSpecialCaracteres(
    {required String value, required String regExp}) {
  return value.replaceAll(RegExp(regExp), '');
}
