import 'package:flutter/material.dart';
import 'package:transparent_image/transparent_image.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Stack(
        children: <Widget>[
          Center(child: CircularProgressIndicator()),
          Center(
            child: FadeInImage.memoryNetwork(
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
              placeholder: kTransparentImage,
              image:
                  'https://img.r7.com/images/wesley-palmeiras-crb-wesley-triste-09062021204812135?dimensions=771x420',
            ),
          ),
        ],
      ),
    );
  }
}
