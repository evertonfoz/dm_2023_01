import 'package:eogas/core/presentation/components/dialogs/custom_dialog/components/inner_dialog_content.dart';
import 'package:eogas/core/presentation/components/dialogs/custom_dialog/components/top_circle_of_dialog.dart';
import 'package:flutter/material.dart';

class Consts {
  Consts._();

  static const double padding = 16.0;
  static const double avatarRadius = 43.0;
}

enum CustomDialogTypes { Success, Fail, Warning, Question }

class CustomDialogInformation extends StatelessWidget {
  final String? leftButtonText, urlToImage, errorToCopy, rigthButtonText;
  final Color? leftButtonColor;
  final String title, description;
  final Color? rightButtonColor;
  final CustomDialogTypes customDialogType;
  final VoidCallback? onLeftButtonPressed;
  final Function? onRigthButtonPressed;

  const CustomDialogInformation({
    required this.title,
    required this.description,
    this.rigthButtonText = 'OK',
    this.customDialogType = CustomDialogTypes.Success,
    this.rightButtonColor = Colors.lightBlueAccent,
    this.leftButtonText,
    this.leftButtonColor,
    this.urlToImage,
    this.onLeftButtonPressed,
    this.onRigthButtonPressed,
    this.errorToCopy,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(Consts.padding),
      ),
      elevation: 0.0,
      backgroundColor: Colors.transparent,
      child: _dialogContent(context),
    );
  }

  _dialogContent(BuildContext context) {
    return Stack(
      children: <Widget>[
        InnerDialogContentWidget(
          title: title,
          description: description,
          customDialogType: customDialogType,
          rigthButtonColor: rightButtonColor,
          leftButtonColor: leftButtonColor,
          onLeftButtonPressed: onLeftButtonPressed,
          leftButtonText: leftButtonText,
          rigthButtonText: rigthButtonText,
          onRigthButtonPressed: onRigthButtonPressed,
          errorToCopy: errorToCopy,
        ),
        TopCircleOfDialogWidget(
          customDialogType: customDialogType,
          urlToImage: urlToImage,
        ),
      ],
    );
  }
}
