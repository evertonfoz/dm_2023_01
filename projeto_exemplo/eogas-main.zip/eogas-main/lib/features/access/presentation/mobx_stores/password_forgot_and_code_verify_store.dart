import 'package:flutter/material.dart';
import 'package:mobx/mobx.dart';

part 'password_forgot_and_code_verify_store.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner build --delete-conflicting-outputs
/// flutter packages pub run build_runner watch --delete-conflicting-outputs

class PasswordForgotAndCodeVerifyStore = _PasswordForgotAndCodeVerifyStore
    with _$PasswordForgotAndCodeVerifyStore;

abstract class _PasswordForgotAndCodeVerifyStore with Store {
  @observable
  bool _emailIsSelected = true;

  @observable
  bool _cellPhoneIsSelected = false;

  @observable
  bool _emailIsValid = false;

  @observable
  bool _cellPhoneIsValid = false;

  @observable
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @observable
  BuildContext? _buildContext;

  @observable
  String _code = '';

  @observable
  String _email = '';

  @observable
  String _cellPhone = '';

  @observable
  bool _codeIsComplete = false;

  @observable
  bool _obscureCode = true;

  @computed
  bool get emailIsSelected => _emailIsSelected;

  @computed
  bool get cellPhoneIsSelected => _cellPhoneIsSelected;

  @computed
  bool get formIsValid =>
      (_emailIsSelected && _emailIsValid) ||
      (_cellPhoneIsSelected && _cellPhoneIsValid);

  @computed
  BuildContext? get buildContext => _buildContext;

  @computed
  String get code => _code;

  @computed
  String get email => _email;

  @computed
  String get cellPhone => _cellPhone;

  @computed
  bool get obscureCode => _obscureCode;

  @computed
  bool get codeIsComplete => _codeIsComplete;

  @action
  registerEmailStatus(bool value) {
    _emailIsValid = value;
  }

  @action
  registerCellPhoneStatus(bool value) {
    _cellPhoneIsValid = value;
  }

  @action
  registerBuildContext({required BuildContext value}) {
    _buildContext = value;
  }

  @action
  registerChangeOfMeansOfRecovery() {
    _emailIsSelected = !_emailIsSelected;
    _cellPhoneIsSelected = !cellPhoneIsSelected;
  }

  @action
  registerCode(String value) {
    _code = value;
  }

  @action
  registerEmail(String value) {
    _email = value;
  }

  @action
  registerCellPhone(String value) {
    _cellPhone = value;
  }

  @action
  registerCodeIsComplete(bool value) {
    _codeIsComplete = value;
  }

  @action
  registerTurnObscureCode() {
    _obscureCode = !_obscureCode;
  }
}
