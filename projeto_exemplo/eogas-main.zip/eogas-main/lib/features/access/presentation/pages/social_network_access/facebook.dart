import 'package:flutter/material.dart';
import 'package:transparent_image/transparent_image.dart';

class FacebookAccessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Stack(
        children: <Widget>[
          Center(child: CircularProgressIndicator()),
          Center(
            child: FadeInImage.memoryNetwork(
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
              placeholder: kTransparentImage,
              image:
                  'https://cdn.meutimao.com.br/_upload/noticia/2017/04/dalessandro-esta-fora-do-jogo-contra-o_8c.jpg',
            ),
          ),
        ],
      ),
    );
  }
}
