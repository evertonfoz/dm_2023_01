import 'package:eogas/core/presentation/router_transition/preferences.dart';
import 'package:eogas/features/access/presentation/mobx_stores/password_forgot_and_code_verify_store.dart';
import 'package:eogas/features/access/presentation/pages/access/access.dart';
import 'package:eogas/features/access/presentation/pages/code_verify/code_verify_to_recover_password.dart';
import 'package:eogas/features/access/presentation/pages/login/login.dart';
import 'package:eogas/features/access/presentation/pages/password_forgot/password_forgot.dart';
import 'package:eogas/features/access/presentation/pages/register/register.dart';
import 'package:eogas/features/access/presentation/pages/social_network_access/facebook.dart';
import 'package:eogas/features/access/presentation/pages/social_network_access/google.dart';
import 'package:eogas/features/home/presentation/pages/home.dart';
import 'package:eogas/features/welcome/presentation/pages/welcome.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

import '../../constants.dart';

class RouterTransition {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case kWelcomeRoute:
        return _getPageTransition(settings, WelcomePage());
      case kAccessPageRoute:
        return _getPageTransition(settings, AccessPage());
      case kLoginPageRoute:
        return _getPageTransition(settings, LoginPage());
      case kRegisterPageRoute:
        return _getPageTransition(settings, RegisterPage());
      case kHomePageRoute:
        return _getPageTransition(settings, HomePage());
      case kFacebookAccessRoute:
        return _getPageTransition(settings, FacebookAccessPage());
      case kGoogleAccessRoute:
        return _getPageTransition(settings, GoogleAccessPage());
      case kPasswordForgot:
        return _getPageTransition(settings, PasswordForgotPage());
      case kCodeVerifyToRecoverPasswordRoute:
        return _getPageTransition(
          settings,
          CodeVerifyToRecoverPasswordPage(
            passwordForgotStore:
                settings.arguments as PasswordForgotAndCodeVerifyStore,
          ),
        );
      default:
        return MaterialPageRoute(
            builder: (_) => Scaffold(
                  body: Center(
                      child: Text('No route defined for ${settings.name}')),
                ));
    }
  }

  static _getPageTransition(RouteSettings settings, Widget route) {
    PageTranstionArgs pageTransition =
        PageTranstionPreferences.getPageTransition();

    /// Tipifiquei o retorno em String pelo fato das search pages retornarem string
    /// no pop(). Ainda é preciso repensar essa situação.
    return PageTransition<String>(
      duration: Duration(milliseconds: 500),
      child: route,
      type: pageTransition.pageTranstionType,
      alignment: pageTransition.alignment,
      settings: settings,
    );
  }
}
